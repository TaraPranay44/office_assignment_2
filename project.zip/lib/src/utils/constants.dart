import 'package:flutter/material.dart';
import 'package:project/src/utils/styles.dart';

Text textFieldHeading = Text(
  'OR LOG IN WITH EMAIL',
  style: outerText,
);
TextButton forgotPassword = TextButton(
    onPressed: () {},
    child: Text('Forgot Password?', style: mediumBlackTextButton));

//app's bottom bar data
class BottomBarData {
  
String label1 = 'Shop';
String label2 = 'Explore';
String label3 = 'Cart';
String label4 = 'Favourite';
String label5 = 'Account';
}

