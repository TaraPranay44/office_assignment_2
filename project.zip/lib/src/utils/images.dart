String girlSitting = 'assets/images/girl_sitting.png';
String backArror = 'assets/images/back_arrow.png';
String facebookIcon = 'assets/images/facebook.png';
String googleIcon = 'assets/images/google.png';
String silentMoon = 'assets/images/silent_moon.png';


String apples = 'assets/images/apples.png';
String smallBackArrow = 'assets/images/back_arrow.png';
String bananas = 'assets/images/bananas.png';
String chicken = 'assets/images/chicken.png';
String garlic = 'assets/images/garlic.png';
String mutton = 'assets/images/mutton.png';
String pulses = 'assets/images/pulses.png';
String redCapsicum = 'assets/images/red_capsicum.png';
String rice = 'assets/images/rice.png';
String vegetablesBanner = 'assets/images/banner.png';

String bakery = 'assets/images/explore_screen_images/bakery.png';
String beverages = 'assets/images/explore_screen_images/beverages.png';
String diary = 'assets/images/explore_screen_images/diary.png';
String fruits = 'assets/images/explore_screen_images/fruits.png';
String oil = 'assets/images/explore_screen_images/oil.png';
String meat = 'assets/images/explore_screen_images/meat.png';
