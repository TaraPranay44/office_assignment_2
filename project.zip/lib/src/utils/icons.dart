
String sendIcon = 'assets/icons/send_icon.png';
String bookmark = 'assets/icons/bookmark.png';
String downArrow = 'assets/icons/down_arrow.png';
String backArrow = 'assets/icons/back_arrow.png';
String slideIcon = 'assets/icons/slide_icons.png';


// explore screen icons 
String search = 'assets/icons/explore_screen_icons/search.png';
String filter = 'assets/icons/explore_screen_icons/filter.png';


