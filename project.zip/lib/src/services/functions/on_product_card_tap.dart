
import 'package:flutter/material.dart';

void onTapCard(BuildContext context){
  Navigator.pushNamed(context, '/product_details_page');
}