// import 'package:flutter/material.dart';

class SignInPage {
  var heading = 'Welcome Back!';
  var hintTextFieldOne = 'Email address';
  var hintTextFieldTwo = 'Password';
  var bottomTExt1 = 'DON\'T HAVE AN ACCOUNT?';
  var bottomTExt2 = 'SIGN UP';
}
