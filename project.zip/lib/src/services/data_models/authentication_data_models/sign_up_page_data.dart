class SignUpPage {
  var heading = 'Create your account';
  var textFieldOne = 'User Name';
  var textFieldOTwo = 'Email address';
  var textFieldThree = 'Password';
  var checkBox1 = 'I have read the';
  var checkBox2 = 'Privacy Policy';
}
