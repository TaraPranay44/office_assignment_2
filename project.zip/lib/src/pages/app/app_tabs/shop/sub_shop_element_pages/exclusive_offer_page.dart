import 'package:flutter/material.dart';

class ExclusiveOfferPage extends StatelessWidget {
  const ExclusiveOfferPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: Text('Exclusive Offer Page'),),
    );
  }
}