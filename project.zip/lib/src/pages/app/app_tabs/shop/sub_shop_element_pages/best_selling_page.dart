import 'package:flutter/material.dart';

class BestSellingPage extends StatelessWidget {
  const BestSellingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: Text('Best Selling Page'),),
    );
  }
}